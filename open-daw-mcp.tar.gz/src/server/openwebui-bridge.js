import { spawn } from 'child_process'
import { join } from 'path'
import { existsSync, mkdirSync, writeFileSync } from 'fs'

/**
 * OpenWebUI MCP Bridge für die DAW
 * 
 * Diese Bridge übersetzt natürliche Sprache in DAW-Befehle
 * und generiert MusicXML basierend auf Textbeschreibungen.
 */
export class OpenWebUIMCPBridge {
  constructor() {
    this.outputDir = join(process.cwd(), 'output')
    this.audioDir = join(this.outputDir, 'audio')
    this.musicxmlDir = join(this.outputDir, 'musicxml')
    
    // Erstelle Output-Verzeichnisse
    this._ensureDirectories()
  }

  _ensureDirectories() {
    if (!existsSync(this.outputDir)) {
      mkdirSync(this.outputDir, { recursive: true })
    }
    if (!existsSync(this.audioDir)) {
      mkdirSync(this.audioDir, { recursive: true })
    }
    if (!existsSync(this.musicxmlDir)) {
      mkdirSync(this.musicxmlDir, { recursive: true })
    }
  }

  /**
   * Gibt die verfügbaren Funktionen für OpenWebUI zurück
   */
  getFunctionDefinitions() {
    return [
      {
        name: "generate_melody",
        description: "Generiert eine Melodie basierend auf einer Textbeschreibung",
        parameters: {
          type: "object",
          properties: {
            description: {
              type: "string",
              description: "Beschreibung der gewünschten Melodie (z.B. 'fröhliche Melodie in C-Dur')"
            },
            duration: {
              type: "number",
              description: "Dauer in Sekunden (Standard: 30)",
              default: 30
            },
            tempo: {
              type: "number", 
              description: "Tempo in BPM (Standard: 120)",
              default: 120
            }
          },
          required: ["description"]
        }
      },
      {
        name: "generate_song",
        description: "Generiert einen kompletten Song mit mehreren Instrumenten",
        parameters: {
          type: "object",
          properties: {
            description: {
              type: "string",
              description: "Beschreibung des gewünschten Songs (z.B. 'fröhlicher Pop-Song mit Gitarre und Schlagzeug')"
            },
            duration: {
              type: "number",
              description: "Dauer in Sekunden (Standard: 60)",
              default: 60
            },
            style: {
              type: "string",
              description: "Musikstil (z.B. 'pop', 'rock', 'jazz', 'electronic')",
              default: "pop"
            }
          },
          required: ["description"]
        }
      }
    ]
  }

  /**
   * Verarbeitet Funktionsaufrufe von OpenWebUI
   */
  async handleFunctionCall(functionName, parameters = {}) {
    console.log(`🎵 Function Call: ${functionName}`, parameters)

    try {
      switch (functionName) {
        case "generate_melody":
          return await this._generateMelody(parameters)
        
        case "generate_song":
          return await this._generateSong(parameters)
        
        default:
          // Natürliche Sprachverarbeitung
          return await this._processNaturalLanguage(functionName, parameters)
      }
    } catch (error) {
      console.error(`❌ Fehler bei Function Call ${functionName}:`, error)
      throw error
    }
  }

  /**
   * Generiert eine einfache Melodie als MusicXML
   */
  async _generateMelody(params) {
    const { description, duration = 30, tempo = 120 } = params
    
    const filename = `melody_${Date.now()}.musicxml`
    const musicxmlPath = join(this.musicxmlDir, filename)
    
    // Einfaches MusicXML für eine Melodie
    const musicxml = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE score-partwise PUBLIC "-//Recordare//DTD MusicXML 3.1 Partwise//EN" "http://www.musicxml.org/dtds/partwise.dtd">
<score-partwise version="3.1">
  <part-list>
    <score-part id="P1">
      <part-name>Melodie</part-name>
    </score-part>
  </part-list>
  <part id="P1">
    <measure number="1">
      <attributes>
        <divisions>480</divisions>
        <key>
          <fifths>0</fifths>
        </key>
        <time>
          <beats>4</beats>
          <beat-type>4</beat-type>
        </time>
        <clef>
          <sign>G</sign>
          <line>2</line>
        </clef>
      </attributes>
      <direction>
        <direction-type>
          <metronome>
            <beat-unit>quarter</beat-unit>
            <per-minute>${tempo}</per-minute>
          </metronome>
        </direction-type>
      </direction>
      <note>
        <pitch>
          <step>C</step>
          <octave>4</octave>
        </pitch>
        <duration>480</duration>
        <type>quarter</type>
      </note>
      <note>
        <pitch>
          <step>D</step>
          <octave>4</octave>
        </pitch>
        <duration>480</duration>
        <type>quarter</type>
      </note>
      <note>
        <pitch>
          <step>E</step>
          <octave>4</octave>
        </pitch>
        <duration>480</duration>
        <type>quarter</type>
      </note>
      <note>
        <pitch>
          <step>F</step>
          <octave>4</octave>
        </pitch>
        <duration>480</duration>
        <type>quarter</type>
      </note>
    </measure>
    <measure number="2">
      <note>
        <pitch>
          <step>G</step>
          <octave>4</octave>
        </pitch>
        <duration>480</duration>
        <type>quarter</type>
      </note>
      <note>
        <pitch>
          <step>A</step>
          <octave>4</octave>
        </pitch>
        <duration>480</duration>
        <type>quarter</type>
      </note>
      <note>
        <pitch>
          <step>B</step>
          <octave>4</octave>
        </pitch>
        <duration>480</duration>
        <type>quarter</type>
      </note>
      <note>
        <pitch>
          <step>C</step>
          <octave>5</octave>
        </pitch>
        <duration>480</duration>
        <type>quarter</type>
      </note>
    </measure>
  </part>
</score-partwise>`

    // Speichere MusicXML
    writeFileSync(musicxmlPath, musicxml)
    
    return {
      success: true,
      song: {
        title: "Generierte Melodie",
        style: "Melodie",
        tempo: tempo,
        key: "C-Dur",
        structure: ["Intro", "Melodie", "Outro"],
        description: description,
        duration: duration
      },
      files: {
        musicxml: filename
      }
    }
  }

  /**
   * Generiert einen kompletten Song als MusicXML
   */
  async _generateSong(params) {
    const { description, duration = 60, style = "pop" } = params
    
    const filename = `song_${Date.now()}.musicxml`
    const musicxmlPath = join(this.musicxmlDir, filename)
    
    // MusicXML für einen Song mit mehreren Stimmen
    const musicxml = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE score-partwise PUBLIC "-//Recordare//DTD MusicXML 3.1 Partwise//EN" "http://www.musicxml.org/dtds/partwise.dtd">
<score-partwise version="3.1">
  <part-list>
    <score-part id="P1">
      <part-name>Melodie</part-name>
    </score-part>
    <score-part id="P2">
      <part-name>Bass</part-name>
    </score-part>
  </part-list>
  <part id="P1">
    <measure number="1">
      <attributes>
        <divisions>480</divisions>
        <key>
          <fifths>0</fifths>
        </key>
        <time>
          <beats>4</beats>
          <beat-type>4</beat-type>
        </time>
        <clef>
          <sign>G</sign>
          <line>2</line>
        </clef>
      </attributes>
      <direction>
        <direction-type>
          <metronome>
            <beat-unit>quarter</beat-unit>
            <per-minute>120</per-minute>
          </metronome>
        </direction-type>
      </direction>
      <note>
        <pitch>
          <step>C</step>
          <octave>5</octave>
        </pitch>
        <duration>960</duration>
        <type>half</type>
      </note>
      <note>
        <pitch>
          <step>E</step>
          <octave>5</octave>
        </pitch>
        <duration>960</duration>
        <type>half</type>
      </note>
    </measure>
  </part>
  <part id="P2">
    <measure number="1">
      <attributes>
        <divisions>480</divisions>
        <key>
          <fifths>0</fifths>
        </key>
        <time>
          <beats>4</beats>
          <beat-type>4</beat-type>
        </time>
        <clef>
          <sign>F</sign>
          <line>4</line>
        </clef>
      </attributes>
      <note>
        <pitch>
          <step>C</step>
          <octave>3</octave>
        </pitch>
        <duration>1920</duration>
        <type>whole</type>
      </note>
    </measure>
  </part>
</score-partwise>`

    // Speichere MusicXML
    writeFileSync(musicxmlPath, musicxml)
    
    return {
      success: true,
      song: {
        title: "Generierter Song",
        style: style,
        tempo: 120,
        key: "C-Dur", 
        structure: ["Intro", "Verse", "Chorus", "Verse", "Chorus", "Outro"],
        description: description,
        duration: duration
      },
      files: {
        musicxml: filename
      }
    }
  }

  /**
   * Verarbeitet natürliche Sprache
   */
  async _processNaturalLanguage(message, context = {}) {
    console.log(`🎵 Natürliche Sprachanfrage: ${message}`)
    
    // Einfache Keyword-basierte Verarbeitung
    const lowerMessage = message.toLowerCase()
    
    if (lowerMessage.includes('melodie') || lowerMessage.includes('melody')) {
      return await this._generateMelody({
        description: message,
        duration: 30
      })
    }
    
    if (lowerMessage.includes('song') || lowerMessage.includes('lied') || lowerMessage.includes('musik')) {
      return await this._generateSong({
        description: message,
        duration: 60
      })
    }
    
    // Fallback: Generiere eine Melodie
    return await this._generateMelody({
      description: message,
      duration: 30
    })
  }
} 